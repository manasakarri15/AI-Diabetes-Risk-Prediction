
# AI-Based Diabetes Risk Prediction

## Project Overview

This project uses Machine Learning and Explainable AI (XAI) to predict the risk of diabetes based on patient health-related features.

## Objective

The main objective is to build an AI-based system that predicts diabetes risk and explains the factors influencing the prediction.

## Dataset

The project uses a diabetes dataset containing 768 patient records and 8 input features.

### Features

- Pregnancies
- Glucose
- BloodPressure
- SkinThickness
- Insulin
- BMI
- DiabetesPedigreeFunction
- Age

### Target

- Outcome

## Machine Learning Models

The following models were evaluated:

1. Logistic Regression
2. Random Forest
3. XGBoost

### Best Model

XGBoost achieved the best overall performance among the evaluated models.

- Accuracy: 75.97%
- Precision: 67.35%
- Recall: 61.11%
- F1 Score: 64.08%
- ROC-AUC: 82.70%

## Explainable AI

SHAP (SHapley Additive exPlanations) is used to explain individual predictions and identify which patient features contributed to the model's prediction.

## Application

A Streamlit web application was developed where users can enter patient information and receive:

- Diabetes risk prediction
- Risk probability
- Risk level
- SHAP-based explanation

## Technologies Used

- Python
- Pandas
- NumPy
- Scikit-learn
- XGBoost
- SHAP
- Matplotlib
- Streamlit

## Disclaimer

This application is intended for educational and research purposes only. It is not a medical diagnostic tool.
